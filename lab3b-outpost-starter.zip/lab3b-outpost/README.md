# CPNT 217 · Lab 3B · The Outpost Listener

You escaped Planet Kaktus. Now you run an **outpost**: a small API server that other crews send messages to.
It saves each message in a CSV file and hands messages to whoever asks for them.

**What's in this folder**

| File | What it is |
|---|---|
| `main.py` | Your API server. It's almost finished: you make a few small changes marked TODO (fill in a value, write a short `if`). |
| `outpost.html` | The retro status screen shown at http://localhost:8000/ (no changes needed). |
| `outpost_check.py` | The **Kaktus Outpost Tester**. Pick a step; it tests that step, gives hints, and remembers your results. |
| `requirements.txt` | The two packages you need: `fastapi` and `uvicorn`. |

---

## Step 1 · Check Python

Open a terminal **in this folder** (Windows: PowerShell or Terminal; Mac: Terminal). Try these until one prints a version (3.10 or newer):

| Windows | Mac |
|---|---|
| `py --version` | `python3 --version` |
| `python --version` | `python --version` |

Whichever word worked (`py`, `python` or `python3`) is **your Python** for the rest of the lab.

## Step 2 · Install FastAPI and uvicorn

Use **one** of these. The `-m pip` versions are the most reliable, because they install into the same Python you'll run.

| If your Python is… | Run |
|---|---|
| `py` (Windows) | `py -m pip install fastapi uvicorn` |
| `python` | `python -m pip install fastapi uvicorn` |
| `python3` (Mac) | `python3 -m pip install fastapi uvicorn` |
| plain pip works | `pip install fastapi uvicorn` or `pip3 install fastapi uvicorn` |

Or install from the file: `python -m pip install -r requirements.txt` (swap in `py` or `python3`).

**Problems?**
- *"pip is not recognized" / "command not found"*: use the `-m pip` form with your Python word.
- *Mac says "externally-managed-environment"*: add `--user`, or make a virtual environment first (below).
- *Permission denied*: add `--user` to the end.

**Optional, but tidy: a virtual environment**
```
python -m venv .venv          (Mac: python3 -m venv .venv · Windows: py -m venv .venv)
.venv\Scripts\activate        (Windows)
source .venv/bin/activate     (Mac)
python -m pip install fastapi uvicorn
```

## Step 3 · Run your outpost

| Windows | Mac |
|---|---|
| `py -m uvicorn main:app --reload --port 8000` | `python3 -m uvicorn main:app --reload --port 8000` |

Wait for `Uvicorn running on http://127.0.0.1:8000`. Then open:
- http://localhost:8000/ : your outpost's status screen
- http://localhost:8000/docs : every endpoint, with **Try it out**

`--reload` restarts the server every time you save `main.py`. Leave this window running; use a **second** terminal for the tester.
Port 8000 busy? Use `--port 8001` (and give the tester 8001).

## Step 4 · Test it

In a second terminal, in this folder:

| Windows | Mac |
|---|---|
| `py outpost_check.py` | `python3 outpost_check.py` |

The first time, press Enter twice for `127.0.0.1` and `8000`. Then you get a menu:

```
   [ OK ]  1  Connect to the outpost
   [FAIL]  2  Receive a message (POST /messages)
   [ -- ]  3  Find one message (GET /messages/{id})
   ...
 What step do you want to test?
```

Type the **number of the step** you're working on. It tests just that step and shows a **hint** for anything that fails.
Fix, save `main.py`, and test the same step again. The tester **remembers** your address and your last results, even after you close it.
`A` tests every step, `S` shows your score, `C` changes the address (to test a partner), `Q` quits.
When steps 1 to 5 all say OK, `S` shows your **CODE** line: paste it into LiveLab.

## Your TODOs (all in `main.py`, each one small)

| Part | Where | What to type |
|---|---|---|
| 2a | top of `post_message` | `if msg.text == "":` then on the next line, indented, `raise HTTPException(400, "Empty message")` |
| 2b | the `new = {...}` dictionary | change `"text": ""` to `"text": msg.text` |
| 3 | `get_message`, replace `pass` | `if m["id"] == message_id:` then, indented, `return m` |
| 4 | `list_messages`, replace `pass` | `if m["to"] == to:` then, indented, `found.append(m)` |
| bonus | `mark_delivered`, replace `pass` | the four lines shown in the comment |

Indentation matters in Python: the line after an `if` is indented 4 more spaces.

## Step 5 · Let another laptop reach you

1. Stop the server (Ctrl+C) and start it so other machines can connect:
   `python -m uvicorn main:app --reload --host 0.0.0.0 --port 8000` (swap in `py` or `python3`)
2. Find your IP: Windows `ipconfig` (IPv4 Address) · Mac: System Settings → Wi-Fi → Details (or `ipconfig getifaddr en0`).
3. Your partner runs the tester on **their** laptop, presses `C`, and types **your** IP and port.
4. Not connecting? Same Wi-Fi? Allow Python through the firewall when asked (Windows Defender Firewall → Allow an app). Your own laptop must work first with 127.0.0.1.

You'll see their requests arrive in your uvicorn window (their IP, the method, the path and the status).
