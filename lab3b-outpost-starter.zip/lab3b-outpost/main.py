"""
CPNT 217 · Lab 3B · The Outpost Listener
=========================================

You escaped Planet Kaktus. Now you run an OUTPOST: a little API server that
other crews send messages to. Your outpost keeps every message in a CSV file
(messages.csv) and hands messages to whoever asks for them.

Already working (read them, they are your examples):
    GET  /          a retro status screen for your outpost (open it in a browser)
    GET  /hello     says hello
    GET  /status    how many messages are waiting

YOUR JOB: the endpoints further down are almost finished. Each TODO is one
small change (fill in a value, or write a short if statement):
    Part 2  POST /messages          refuse empty messages; save the text
    Part 3  GET  /messages/{id}     send back the message with that id
    Part 4  GET  /messages?to=NAME  list the messages for NAME
    BONUS   POST /messages/{id}/delivered   mark a message delivered

Run it (pick the line that works on your computer):
    python -m uvicorn main:app --reload --port 8000
    py -m uvicorn main:app --reload --port 8000          (Windows)
    python3 -m uvicorn main:app --reload --port 8000     (Mac)

Then test it with the Kaktus tester:  python outpost_check.py
"""
import csv
import os
from datetime import datetime

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

# ---------------------------------------------------------------------------
# 1. Name your outpost (letters, numbers and dashes). The tester shows it.
# ---------------------------------------------------------------------------
OUTPOST_NAME = "outpost-change-me"

app = FastAPI(
    title="Outpost Listener",
    description="A tiny message outpost for CPNT 217 Lab 3B. Crews POST messages here; anyone can ask for theirs.",
)

# ---------------------------------------------------------------------------
# 2. The CSV "database". These helpers are done for you: use them.
# ---------------------------------------------------------------------------
CSV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "messages.csv")
COLUMNS = ["id", "sender", "to", "text", "sent_at", "delivered"]


def read_messages():
    """Return every message as a list of dictionaries (an empty list if there is no file yet)."""
    if not os.path.exists(CSV_FILE):
        return []
    with open(CSV_FILE, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        row["id"] = int(row["id"])
        row["delivered"] = row["delivered"] == "yes"
    return rows


def save_messages(messages):
    """Write the whole list of message dictionaries back to the CSV file."""
    with open(CSV_FILE, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNS)
        writer.writeheader()
        for m in messages:
            row = dict(m)
            row["delivered"] = "yes" if m["delivered"] else "no"
            writer.writerow(row)


def next_id(messages):
    """The id for a new message: one more than the biggest id so far (1 for the first)."""
    if not messages:
        return 1
    return max(m["id"] for m in messages) + 1


def now():
    """The time right now, as text like 2026-11-24 14:05:09."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# What a new message must look like in the JSON body of POST /messages.
# FastAPI checks it for you: a missing field gets a 422 automatically.
class NewMessage(BaseModel):
    sender: str
    to: str
    text: str


# ---------------------------------------------------------------------------
# 3. Endpoints that already work. Read them: they show the pattern.
# ---------------------------------------------------------------------------
@app.get("/hello")
def hello(name: str = "traveller"):
    """Say hello. Try /hello?name=Ada"""
    return {"outpost": OUTPOST_NAME, "message": f"Hello, {name}! This is outpost {OUTPOST_NAME}."}


@app.get("/status")
def status():
    """How many messages this outpost holds, and how many are still waiting to be delivered."""
    messages = read_messages()
    waiting = 0
    for m in messages:
        if not m["delivered"]:
            waiting = waiting + 1
    return {
        "outpost": OUTPOST_NAME,
        "total": len(messages),
        "waiting": waiting,
        "delivered": len(messages) - waiting,
        "time": now(),
    }


# ---------------------------------------------------------------------------
# 4. YOUR PART. The endpoints below are almost finished. Each TODO is ONE small
#    change: fill in a value, or write a short `if` statement.
#    Save the file after each change (the server reloads), then run the tester.
# ---------------------------------------------------------------------------

@app.post("/messages", status_code=201)
def post_message(msg: NewMessage):
    """Save a new message. Body: {"sender": "...", "to": "...", "text": "..."}. Returns its id."""

    # TODO Part 2a: refuse an empty message. Write an if statement:
    #     if msg.text == "":
    #         raise HTTPException(400, "Empty message: put something in text")

    messages = read_messages()
    new = {
        "id": next_id(messages),
        "sender": msg.sender,
        "to": msg.to,
        "text": "",          # TODO Part 2b: replace "" with the message's text (look at the two lines above)
        "sent_at": now(),
        "delivered": False,
    }
    messages.append(new)
    save_messages(messages)
    return {"id": new["id"], "saved": True}


@app.get("/messages/{message_id}")
def get_message(message_id: int):
    """Get one message by its id, e.g. /messages/3. 404 if there is no such message."""
    for m in read_messages():
        # TODO Part 3: if this message's id is the one asked for, send it back:
        #     if m["id"] == message_id:
        #         return m
        pass
    raise HTTPException(404, f"No message {message_id}")


@app.get("/messages")
def list_messages(to: str):
    """The messages still waiting for one crew, e.g. /messages?to=Ada"""
    found = []
    for m in read_messages():
        if m["delivered"]:
            continue          # skip messages that were already delivered
        # TODO Part 4: if this message is for the crew asked about, add it to the list:
        #     if m["to"] == to:
        #         found.append(m)
        pass
    return {"to": to, "count": len(found), "messages": found}


# BONUS (Part 7): mark a message delivered, so it stops showing as waiting.
@app.post("/messages/{message_id}/delivered")
def mark_delivered(message_id: int):
    """Mark one message delivered, e.g. POST /messages/3/delivered. 404 if there is no such message."""
    messages = read_messages()
    for m in messages:
        # TODO BONUS: if m["id"] == message_id:
        #                 m["delivered"] = True
        #                 save_messages(messages)
        #                 return {"id": message_id, "delivered": True}
        pass
    raise HTTPException(404, f"No message {message_id}")


# ---------------------------------------------------------------------------
# 5. The retro status screen at /  (done for you; just enjoy it)
# ---------------------------------------------------------------------------
@app.get("/", response_class=HTMLResponse, include_in_schema=False)
def screen():
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "outpost.html"), encoding="utf-8") as f:
        return f.read()
