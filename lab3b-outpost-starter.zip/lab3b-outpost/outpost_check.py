"""
CPNT 217 · Lab 3B · Kaktus Outpost Tester
==========================================
Tests your Outpost Listener one step at a time, remembers your results,
and gives you a hint for anything that doesn't work yet.
Uses only Python's standard library: nothing to install.

    python outpost_check.py          (Windows: py outpost_check.py · Mac: python3 outpost_check.py)

Then pick a step from the menu. Fix, save main.py, pick the step again.
"""
import hashlib
import json
import os
import random
import sys
import urllib.error
import urllib.request

TESTER_VERSION = "3B.3"
_SALT = "kaktus-outpost-f26"     # makes the result code; changing it just makes your code not match
HERE = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = os.path.join(HERE, "outpost_results.json")

if os.name == "nt":
    os.system("")                # turns on colours in the Windows terminal

G, Y, R, C, M, DIM, OFF = "\033[92m", "\033[93m", "\033[91m", "\033[96m", "\033[95m", "\033[2m", "\033[0m"

BANNER = rf"""{G}
        _  _                 {C}  K A K T U S   O U T P O S T   T E S T E R{G}
       | || | _              {DIM}  CPNT 217 · Lab 3B · v{TESTER_VERSION}{OFF}{G}
    _  | || || |
   | |_| || || |    {Y}   .    *        .      *     .{G}
    \_   || |_/     {Y}         ___               {G}
      |  || |       {Y}   *    /___\   incoming message...{G}
      |  ||_|       {Y}       |  o |          .{G}
      |__||         {Y}  .     \___/      *{G}
  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~{OFF}"""

# Every check, in a fixed order (the result code depends on it).
CHECKS = ["hello", "status", "post", "post422", "getone", "get404", "list", "count", "postempty"]
CHECK_NAMES = {
    "hello": "GET /hello answers",
    "status": "GET /status reports total and waiting",
    "post": "POST /messages saves a message (201 + id)",
    "post422": "POST /messages with no text field is refused (422)",
    "postempty": "POST /messages with empty text is refused (400)",
    "getone": "GET /messages/{id} returns that message, with its text",
    "get404": "GET /messages/987654 says 404",
    "list": "GET /messages?to=NAME finds exactly that crew's message",
    "count": "GET /status counts a new message",
    "bonus": "BONUS: a delivered message stops waiting",
}

# The menu: each step tests a few checks.
STEPS = [
    ("1", "Connect to the outpost",              "Part 1",  ["hello", "status"]),
    ("2", "Receive a message (POST /messages)",  "Part 2",  ["post", "post422", "postempty"]),
    ("3", "Find one message (GET /messages/{id})", "Part 3", ["getone", "get404"]),
    ("4", "Messages for a crew (GET /messages?to=)", "Part 4", ["list"]),
    ("5", "Status counts new messages",          "Part 2",  ["count"]),
    ("6", "BONUS: mark delivered",               "Part 7",  ["bonus"]),
]


# ---------------------------------------------------------------- saving
def load_saved():
    try:
        with open(SAVE_FILE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {"address": None, "results": {}}


def save(state):
    try:
        with open(SAVE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=1)
    except OSError:
        pass


# ---------------------------------------------------------------- talking to the API
def call(base, method, path, body=None):
    """Send one request. Returns (status, json_or_text, error_message)."""
    data = None
    headers = {"Accept": "application/json"}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(base + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            raw, status = r.read().decode("utf-8", "replace"), r.status
    except urllib.error.HTTPError as e:
        raw, status = e.read().decode("utf-8", "replace"), e.code
    except Exception as e:
        return None, None, str(e)
    try:
        return status, json.loads(raw), None
    except ValueError:
        return status, raw, None


def new_crew():
    return "crew-" + "".join(random.choice("abcdef0123456789") for _ in range(5))


TEXTS = ["Spare fuel cells at sector 7", "Watch out for the sand worms", "Red cactus blooms at dawn",
         "Meet at the relay tower", "The lantern is on"]

NO_CONNECTION = ("Is uvicorn running in another window? Same port number? "
                 "Testing another laptop: they start uvicorn with --host 0.0.0.0, you use THEIR IP (not 127.0.0.1), "
                 "same Wi-Fi, and Python is allowed through their firewall.")


def post_one(base, who=None):
    """Post a test message. Returns (status, id, text, who)."""
    who = who or new_crew()
    text = random.choice(TEXTS)
    s, j, err = call(base, "POST", "/messages", {"sender": "Kaktus Command", "to": who, "text": text})
    new_id = j.get("id") if isinstance(j, dict) else None
    return s, (new_id if isinstance(new_id, int) else None), text, who, err


# ---------------------------------------------------------------- the checks
# Each returns a list of (key, ok, detail, hint).

def test_connect(base):
    out = []
    s, j, err = call(base, "GET", "/hello?name=Kaktus%20Command")
    if err:
        return [("hello", False, err, NO_CONNECTION)]
    ok = s == 200 and isinstance(j, dict) and "outpost" in j
    out.append(("hello", ok, f"{s} · {j}", "Keep the starter's /hello endpoint: it must return JSON with \"outpost\"."))
    s, j, _ = call(base, "GET", "/status")
    ok = s == 200 and isinstance(j, dict) and isinstance(j.get("total"), int) and isinstance(j.get("waiting"), int)
    out.append(("status", ok, f"{s} · {j}", "Keep the starter's /status endpoint (total, waiting and delivered)."))
    return out


def test_receive(base):
    out = []
    s, new_id, text, who, err = post_one(base)
    if err:
        return [("post", False, err, NO_CONNECTION)]
    hint = "Look at the uvicorn window for a red error and the line number."
    if s == 200:
        hint = "It returned 200: keep status_code=201 in the @app.post line."
    elif s == 400:
        hint = "Your empty-text if is refusing every message. It should be:  if msg.text == \"\":  (two quote marks, nothing between)."
    elif s == 500:
        hint = "Your code crashed (500). Read the red error in the uvicorn window: it names the line. Check indentation after your if."
    out.append(("post", s == 201 and new_id is not None, f"{s} · id {new_id}", hint))

    s, j, _ = call(base, "POST", "/messages", {"sender": "Kaktus Command", "to": who})
    out.append(("post422", s == 422, f"{s}", "Keep  msg: NewMessage  as the parameter: FastAPI then refuses a body with no text for you."))

    s, j, _ = call(base, "POST", "/messages", {"sender": "Kaktus Command", "to": who + "-x", "text": ""})
    out.append(("postempty", s == 400, f"{s} · {j}",
                "Part 2a: at the top of post_message type\n"
                "              if msg.text == \"\":\n"
                "                  raise HTTPException(400, \"Empty message\")"))

    # Peek at Part 2b (the text) if Part 3 already works.
    if new_id is not None:
        s, j, _ = call(base, "GET", f"/messages/{new_id}")
        if s == 200 and isinstance(j, dict) and j.get("text") == "":
            out.append(("_note", f"{Y}note: your message was saved with EMPTY text. Part 2b: change \"text\": \"\" to \"text\": msg.text{OFF}"))
        elif s == 200 and isinstance(j, dict) and j.get("text") == text:
            out.append(("_note", f"{G}note: the text was saved too (Part 2b is done).{OFF}"))
        else:
            out.append(("_note", f"{DIM}note: Part 2b (saving msg.text) gets checked in step 3, once Part 3 works.{OFF}"))
    return out


def test_find(base):
    s, new_id, text, who, err = post_one(base)
    if err:
        return [("getone", False, err, NO_CONNECTION)]
    if new_id is None:
        return [("getone", False, f"couldn't post a test message ({s})", "Step 2 has to work first: run step 2.")]
    out = []
    s, j, _ = call(base, "GET", f"/messages/{new_id}")
    ok = s == 200 and isinstance(j, dict) and j.get("text") == text and j.get("to") == who
    if s == 404:
        hint = ("Part 3: in get_message, replace  pass  with\n"
                "              if m[\"id\"] == message_id:\n"
                "                  return m")
    elif s == 200 and isinstance(j, dict) and j.get("text") == "":
        hint = "Found it, but its text is empty. Part 2b: in post_message change \"text\": \"\" to \"text\": msg.text"
    elif s == 500:
        hint = "Crash (500): read the red error in the uvicorn window. Check the 4-space indent under your if."
    else:
        hint = "Return the whole message m (not just its text)."
    out.append(("getone", ok, f"{s} · {j}", hint))
    s, j, _ = call(base, "GET", "/messages/987654")
    out.append(("get404", s == 404, f"{s} · {j}",
                "Keep the  raise HTTPException(404, ...)  line AFTER the loop (not inside it)."))
    return out


def test_list(base):
    s, new_id, text, who, err = post_one(base)
    if err:
        return [("list", False, err, NO_CONNECTION)]
    if new_id is None:
        return [("list", False, f"couldn't post a test message ({s})", "Step 2 has to work first: run step 2.")]
    s, j, _ = call(base, "GET", f"/messages?to={who}")
    msgs = j.get("messages") if isinstance(j, dict) else None
    count = j.get("count") if isinstance(j, dict) else None
    ok = s == 200 and isinstance(msgs, list) and len(msgs) == 1 and msgs[0].get("to") == who and count == 1
    if isinstance(msgs, list) and len(msgs) == 0:
        hint = ("Part 4: in list_messages, replace  pass  with\n"
                "              if m[\"to\"] == to:\n"
                "                  found.append(m)")
    elif isinstance(msgs, list) and len(msgs) > 1:
        hint = "You returned more than this crew's message: your if must compare m[\"to\"] with to."
    else:
        hint = "Return {\"to\": to, \"count\": len(found), \"messages\": found} (the starter's last line)."
    return [("list", ok, f"{s} · count {count}", hint)]


def test_count(base):
    s, before, err = call(base, "GET", "/status")
    if err:
        return [("count", False, err, NO_CONNECTION)]
    s, new_id, text, who, err = post_one(base)
    s2, after, _ = call(base, "GET", "/status")
    ok = (isinstance(before, dict) and isinstance(after, dict) and new_id is not None
          and after.get("total") == before.get("total", 0) + 1 and after.get("waiting") == before.get("waiting", 0) + 1)
    b = f"{before.get('total')}/{before.get('waiting')}" if isinstance(before, dict) else "?"
    a = f"{after.get('total')}/{after.get('waiting')}" if isinstance(after, dict) else "?"
    return [("count", ok, f"total/waiting before {b}, after {a}",
             "Step 2 has to work first. Keep save_messages(messages) in post_message so the CSV file gets the message.")]


def test_bonus(base):
    s, new_id, text, who, err = post_one(base)
    if err:
        return [("bonus", False, err, NO_CONNECTION)]
    if new_id is None:
        return [("bonus", False, "couldn't post a test message", "Step 2 has to work first.")]
    s, j, _ = call(base, "POST", f"/messages/{new_id}/delivered")
    s2, j2, _ = call(base, "GET", f"/messages?to={who}")
    gone = isinstance(j2, dict) and j2.get("count") == 0
    hint = "BONUS: in mark_delivered, replace  pass  with the four lines shown in the comment."
    if s == 200 and not gone:
        hint = "Marked it, but it still shows as waiting: step 4 (list_messages) must work first."
    return [("bonus", s == 200 and gone, f"{s} · then waiting for that crew: {j2.get('count') if isinstance(j2, dict) else '?'}", hint)]


TESTS = {"1": test_connect, "2": test_receive, "3": test_find, "4": test_list, "5": test_count, "6": test_bonus}


# ---------------------------------------------------------------- screens
def mark(results, keys):
    vals = [results.get(k) for k in keys]
    if all(v is True for v in vals):
        return f"{G}[ OK ]{OFF}"
    if any(v is False for v in vals):
        return f"{R}[FAIL]{OFF}"
    return f"{DIM}[ -- ]{OFF}"


def show_result(key, ok, detail, hint):
    print(f"   {G + '[ OK ]' if ok else R + '[FAIL]'}{OFF} {CHECK_NAMES[key]}")
    print(f"          {DIM}{detail}{OFF}")
    if not ok and hint:
        print(f"          {Y}hint: {hint}{OFF}")


def score_box(state):
    res = state["results"].get(state["address"], {})
    passed = [k for k in CHECKS if res.get(k) is True]
    bonus = res.get("bonus") is True
    outpost = res.get("_outpost", "?")
    keys = passed + (["bonus"] if bonus else [])
    code = hashlib.sha256(f"{outpost}|{','.join(keys)}|{_SALT}".encode()).hexdigest()[:8].upper()
    bar = G + "#" * len(passed) + DIM + "." * (len(CHECKS) - len(passed)) + OFF
    print(f"\n {C}======================================================{OFF}")
    print(f"   OUTPOST  {outpost}   at {state['address']}")
    print(f"   SCORE    [{bar}] {len(passed)}/{len(CHECKS)}" + (f"  {M}+ BONUS{OFF}" if bonus else ""))
    if len(passed) == len(CHECKS):
        print(f"   CODE     {Y}{outpost}-{len(passed)}{'B' if bonus else ''}-{code}{OFF}   <- paste this into LiveLab")
        print(f"\n   {G}*** OUTPOST ONLINE. Every crew can reach you. Well done! ***{OFF}")
    else:
        print(f"   CODE     {DIM}appears when every step 1-5 says OK{OFF}")
    print(f" {C}======================================================{OFF}")


def ask_address(state):
    old = state.get("address") or "http://127.0.0.1:8000"
    host_old, port_old = old.replace("http://", "").rsplit(":", 1)
    print(f"\n {C}Which outpost?{OFF} Press Enter to keep the value in [brackets].")
    host = input(f"   IP address [{host_old}]: ").strip() or host_old
    port = input(f"   Port       [{port_old}]: ").strip() or port_old
    state["address"] = f"http://{host}:{port}"
    state["results"].setdefault(state["address"], {})
    save(state)


def run_step(state, number):
    base = state["address"]
    res = state["results"].setdefault(base, {})
    title = next(s[1] for s in STEPS if s[0] == number)
    print(f"\n {M}>> Step {number}: {title}  ({base}){OFF}")
    for item in TESTS[number](base):
        if item[0] == "_note":
            print(f"   {item[1]}")
            continue
        key, ok, detail, hint = item
        res[key] = bool(ok)
        show_result(key, ok, detail, hint)
    s, j, _ = call(base, "GET", "/hello")
    if isinstance(j, dict) and j.get("outpost"):
        res["_outpost"] = j["outpost"]
        if j["outpost"] == "outpost-change-me":
            print(f"   {Y}tip: give your outpost a name: OUTPOST_NAME near the top of main.py{OFF}")
    save(state)


def menu(state):
    res = state["results"].get(state["address"], {})
    print(f"\n {C}Testing {state['address']}{OFF}   {DIM}(last results are remembered){OFF}\n")
    for number, title, part, keys in STEPS:
        print(f"   {mark(res, keys)}  {number}  {title}  {DIM}{part}{OFF}")
    print(f"\n   {C}A{OFF}  test every step     {C}S{OFF}  score and LiveLab code     "
          f"{C}C{OFF}  change address     {C}Q{OFF}  quit")
    return input(f"\n {C}What step do you want to test?{OFF} ").strip().upper()


def main():
    print(BANNER)
    state = load_saved()
    state.setdefault("results", {})
    if len(sys.argv) >= 3:                       # quick mode: python outpost_check.py IP PORT
        state["address"] = f"http://{sys.argv[1]}:{sys.argv[2]}"
        state["results"].setdefault(state["address"], {})
        for number in TESTS:
            run_step(state, number)
        score_box(state)
        return
    if not state.get("address"):
        ask_address(state)
    while True:
        choice = menu(state)
        if choice in TESTS:
            run_step(state, choice)
            input(f"\n {DIM}Press Enter for the menu...{OFF}")
        elif choice == "A":
            for number in TESTS:
                run_step(state, number)
            score_box(state)
            input(f"\n {DIM}Press Enter for the menu...{OFF}")
        elif choice == "S":
            score_box(state)
            input(f"\n {DIM}Press Enter for the menu...{OFF}")
        elif choice == "C":
            ask_address(state)
        elif choice in ("Q", "X", "EXIT", "QUIT"):
            print(f"\n {G}Good luck, outpost keeper.{OFF}\n")
            return
        else:
            print(f" {Y}Type a step number (1-6), or A, S, C or Q.{OFF}")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print()
